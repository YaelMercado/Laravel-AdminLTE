<?php $__env->startSection('icon_page', 'unlock-alt'); ?>

<?php $__env->startSection('title', 'Cursos contratados'); ?>

<?php $__env->startSection('menu_pagina'); ?>	
		
	<li role="presentation">
		<a href="/course/view-into-course-prev/<?php echo e($courses->id); ?>" class="link_menu_page">
			<i class="fa fa-user"></i> Cursos
		</a>								
	</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
    <div class="box box-primary">
		<div class="box-body">
			<div class="row" style="height: calc(100vh - 220px) !important;">

                <div class="row">
                    <div class="col-md-12">
                        <img src="/img/logo_int.png" style="width: 25%; padding:5px;" alt="">
                    </div>
                </div>
            
                <div class="row" style="margin: auto; padding-top: 5%;">
                    <div class="col-md-4">
                        <div class="col-md-10 col-md-offset-1">
                            <h4 class="text-center">ESTANCIA SEMESTRAL</h4>
                        </div>

                        <div class="col-md-10 col-md-offset-1" style="">
                            <img src="<?php echo e(url('/img/estancia_semetral.png')); ?>" style="width: 100%;" alt="">
                        </div>

                        <div class="col-md-8 col-md-offset-2">
                            <a href="/course/view-into-course-inter/<?php echo e($courses->id); ?>?estancia=3" class="btn btn-success" style="color:white; width:100%; border-radius: 10px; margin-top: 10px;">CONOCE MÁS</a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="col-md-10 col-md-offset-1">
                            <h4 class="text-center">ESTANCIA CORTA</h4>
                        </div>
                        
                        <div class="col-md-10 col-md-offset-1" style="">
                            <img src="<?php echo e(url('/img/estancia_corta.png')); ?>" style="width: 100%;" alt="">
                        </div>

                        <div class="col-md-8 col-md-offset-2">
                            <a href="/course/view-into-course-inter/<?php echo e($courses->id); ?>?estancia=1" class="btn btn-success" style="color:white; width:100%; border-radius: 10px; margin-top: 10px;">CONOCE MÁS</a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="col-md-10 col-md-offset-1">
                            <h4 class="text-center">ESTANCIA VERANO</h4>
                        </div>
                        
                        <div class="col-md-10 col-md-offset-1" style="">
                            <img src="<?php echo e(url('/img/estancia_verano.png')); ?>" style="width: 100%;" alt="">
                        </div>

                        <div class="col-md-8 col-md-offset-2">
                            <a href="/course/view-into-course-inter/<?php echo e($courses->id); ?>?estancia=2" class="btn btn-success" style="color:white; width:100%; border-radius: 10px; margin-top: 10px;">CONOCE MÁS</a>
                        </div>
                    </div>
                </div>
                
			</div>
		</div>
	</div>    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.AdminLTE._includes._data_tables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.AdminLTE.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yael/Documents/Proyectos/Sistema de internalización/Laravel-AdminLTE/resources/views/courses/view_course_into_internalizacion.blade.php ENDPATH**/ ?>