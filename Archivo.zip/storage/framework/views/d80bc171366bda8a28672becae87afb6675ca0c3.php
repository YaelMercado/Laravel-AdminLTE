<?php $__env->startSection('icon_page', 'eye'); ?>

<?php $__env->startSection('title', 'View User'); ?>

<?php $__env->startSection('menu_pagina'); ?>	
		
	<li role="presentation">
		<a href="<?php echo e(route('user')); ?>" class="link_menu_page">
			<i class="fa fa-user"></i> Usuarios
		</a>								
	</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
    <?php if($user->id != 1): ?>    
        <div class="box box-primary">
    		<div class="box-body">
    			<div class="row">
    				<div class="col-md-12">	
    					<div class="col-lg-3 text-center">
                            <br>
                            <?php if(file_exists($user->avatar)): ?>
                              <img src="<?php echo e(asset($user->avatar)); ?>" class="profile-user-img img-responsive img-circle">
                            <?php else: ?>
                              <img src="<?php echo e(asset('public/img/config/nopic.png')); ?>" class="profile-user-img img-responsive img-circle">
                            <?php endif; ?>
                            <h3 class="profile-username text-center">
                                <?php echo e($user->name); ?>    
                            </h3>                        
                            <?php if($user->active == true): ?>
                                <span class="label label-success">Activo</span>
                            <?php else: ?>
                                <span class="label label-danger">Inactivo</span>
                            <?php endif; ?>                        
                        </div>
                        <div class="col-lg-9">
                            <div class="attachment">
                                <h4><b>Correo: </b></h4>
                                <span><?php echo e($user->email); ?></span>
                                <h4><b>Perfil</b></h4>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(in_array($role->id, $roles_ids)): ?>
                                        <span style="font-size:12px;" class="label label-primary"><?php echo e($role->name); ?></span> 
                                    <?php endif; ?>                                             
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <br><br>
                                <?php if($empresas): ?>
                                <h4><b>Universidad Inscrita</b></h4>
                                <span style="font-size:12px;" class="label label-warning"><?php echo e($empresas->name); ?></span> 
                                <br><br>
                                <?php endif; ?>
                                
                                <p class="help-block"><i class="fa fa-clock-o"></i> Creado: <?php echo e($user->created_at->format('d/m/Y H:i')); ?></p>
                                <p class="help-block"><i class="fa fa-refresh"></i> Ultima modificación: <?php echo e($user->updated_at->format('d/m/Y H:i')); ?></p>
                                <br>
                                <div class="pull-right">                            
                                    <a href="<?php echo e(route('user.edit.password', $user->id)); ?>" title="Change Password <?php echo e($user->name); ?>"><button type="button" class="btn btn-primary btn-sm btn-flat"><i class="fa fa-key"></i> Cambiar contraseña</button></a>
                                    <a href="<?php echo e(route('user.edit', $user->id)); ?>" title="Edit <?php echo e($user->name); ?>"><button type="button" class="btn btn-warning btn-sm btn-flat"><i class="fa fa-pencil"></i> Editar</button></a>
                                </div>
                            </div>
                        </div>
    				</div>
    			</div>
    		</div>
    	</div>    
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLTE.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yael/Documents/Proyectos/Sistema de internalización/Laravel-AdminLTE/resources/views/users/show.blade.php ENDPATH**/ ?>