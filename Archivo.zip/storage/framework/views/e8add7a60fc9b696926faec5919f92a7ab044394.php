<aside class="main-sidebar">
	<section class="sidebar">
		<ul class="sidebar-menu" data-widget="tree">
			<li class="header" style="color:#fff;"> Menu <i class="fa fa-level-down"></i></li>  
			<li class="
						<?php echo e(Request::segment(1) === null ? 'active' : null); ?>

						<?php echo e(Request::segment(1) === 'home' ? 'active' : null); ?>

					  ">
				<a href="<?php echo e(route('home')); ?>" title="Dashboard"><i class="fa fa-dashboard"></i> <span> Inicio</span></a>
			</li>
					<?php if(Auth::user()->can('show-course', '')): ?>
					
					<li class="
						<?php echo e(Request::segment(1) === 'course' ? 'active' : null); ?>

						">
						<a href="<?php echo e(route('course')); ?>" title="Cursos">
							<i class="fa fa-book" aria-hidden="true"></i> <span> Cursos</span>
						</a>
					</li>
					<?php endif; ?>
					<?php if(Auth::user()->can('show-estancia', '')): ?>
					<li class="
						<?php echo e(Request::segment(1) === 'estancias' ? 'active' : null); ?>

						">
						<a href="<?php echo e(route('estancias')); ?>" title="Estancias">
							<i class="fa fa-globe"></i> <span> Estancias</span>
						</a>
					</li>
					<li class="
						<?php echo e(Request::segment(1) === 'instructor' ? 'active' : null); ?>

						">
						<a href="<?php echo e(route('estancias')); ?>" title="Estancias">
							<i class="fa fa-user-circle"></i> <span> Instructuros</span>
						</a>
					</li>
					<li class="
						<?php echo e(Request::segment(1) === 'carrers' ? 'active' : null); ?>

						">
						<a href="<?php echo e(route('estancias')); ?>" title="Estancias">
							<i class="fa fa-university"></i> <span> Carreras</span>
						</a>
					</li>
					<?php endif; ?>
					<?php if(Auth::user()->can('show-company', '')): ?>
					<li class="
						<?php echo e(Request::segment(1) === 'company' ? 'active' : null); ?>

						">
						<a href="<?php echo e(route('company')); ?>" title="Cursos">
							<i class="fa fa-building"></i> <span> Universidades</span>
						</a>
					</li>
					<?php endif; ?>

			<?php if(Request::segment(1) === 'profile'): ?>

			<li class="<?php echo e(Request::segment(1) === 'profile' ? 'active' : null); ?>">
				<a href="<?php echo e(route('profile')); ?>" title="Profile"><i class="fa fa-user"></i> <span> Perfil</span></a>
			</li>

			<?php endif; ?>

			<li class="treeview 
				<?php echo e(Request::segment(1) === 'config' ? 'active menu-open' : null); ?>

				<?php echo e(Request::segment(1) === 'user' ? 'active menu-open' : null); ?>

				<?php echo e(Request::segment(1) === 'role' ? 'active menu-open' : null); ?>

				">
				<a href="#">
					<i class="fa fa-gear"></i>
					<span>Configuración</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
				<ul class="treeview-menu">
					<?php if(Auth::user()->can('root-dev', '')): ?>
						<li class="<?php echo e(Request::segment(1) === 'config' && Request::segment(2) === null ? 'active' : null); ?>">
							<a href="<?php echo e(route('config')); ?>" title="App Config">
								<i class="fa fa-gear"></i> <span> Configuración de Plataforma</span>
							</a>
						</li>
					<?php endif; ?>					
					<li class="
						<?php echo e(Request::segment(1) === 'user' ? 'active' : null); ?>

						<?php echo e(Request::segment(1) === 'role' ? 'active' : null); ?>

						">
						<a href="<?php echo e(route('user')); ?>" title="Users">
							<i class="fa fa-user"></i> <span> Usuarios</span>
						</a>
					</li>
				</ul>
			</li>      
		</ul>
	</section>
</aside><?php /**PATH /Users/yael/Documents/Proyectos/Sistema de internalización/Laravel-AdminLTE/resources/views/layouts/AdminLTE/_includes/_menu_lateral.blade.php ENDPATH**/ ?>