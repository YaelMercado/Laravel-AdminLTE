<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('layouts.AdminLTE._includes._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body class="hold-transition skin-<?php echo e(\App\Models\Config::find(1)->skin); ?> <?php echo e(\App\Models\Config::find(1)->layout); ?> sidebar-mini">
        <div class="wrapper">
            
            <?php echo $__env->make('layouts.AdminLTE._includes._menu_superior', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            <?php echo $__env->make('layouts.AdminLTE._includes._menu_lateral', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <div class="content-wrapper">
                <nav class="navbar navbar-static-top" id="menu_sup_corpo" style="background-color:#d2d6de; margin-bottom:0; padding-bottom:0;navbar-header.a:color:#fff;">      
                    <div class="navbar-header">
                        <a href="" class="navbar-brand" id="" style="color:#222d32;'"><i class="fa fa-<?php echo $__env->yieldContent('icon_page'); ?>"></i> <?php echo $__env->yieldContent('title'); ?></a>
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse-2" aria-expanded="false">
                            <i class="fa fa-bars"></i>
                        </button>
                    </div>
                    <div class="navbar-collapse collapse" id="navbar-collapse-2" aria-expanded="false" style="height: 1px;">
                        <ul class="nav navbar-nav">                            

                            <?php echo $__env->yieldContent('menu_pagina'); ?>

                        </ul>
                    </div>
                </nav>  

                <?php if(Session::has('flash_message')): ?>
                    
                    <div class="<?php echo e(Session::get('flash_message')['class']); ?>" style="padding: 10px 20px;" id="flash_message">
                        <div style="color: #fff; display: inline-block; margin-right: 10px;">
                            <?php echo Session::get('flash_message')['msg']; ?>

                        </div> 
                    </div>

                <?php endif; ?>                
                
                <section class="content">
                    <div class="row">
                        <div class="col-md-12">

                            <?php echo $__env->yieldContent('content'); ?>

                        </div>
                    </div>
                </section>              

            </div>

            <?php echo $__env->make('layouts.AdminLTE._includes._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>       

        <?php echo $__env->make('layouts.AdminLTE._includes._script_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </body>
</html><?php /**PATH /Users/yael/Documents/Proyectos/Sistema de internalización/Laravel-AdminLTE/resources/views/layouts/AdminLTE/index.blade.php ENDPATH**/ ?>