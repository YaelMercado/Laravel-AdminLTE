<?php $__env->startSection('icon_page', 'pencil'); ?>

<?php $__env->startSection('title', 'Edit User Password'); ?>

<?php $__env->startSection('menu_pagina'); ?>	
		
	<li role="presentation">
		<a href="<?php echo e(route('user')); ?>" class="link_menu_page">
			<i class="fa fa-user"></i> Usuarios
		</a>								
	</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
    <?php if($user->id != 1): ?>   
        <div class="box box-primary">
    		<div class="box-body">
    			<div class="row">
    				<div class="col-md-12">	
    					 <form action="<?php echo e(route('user.update.password',$user->id)); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_method" value="put">
                            <div class="row">                            
                                <div class="col-lg-6">
                                    <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                                        <label for="nome">Contraseña</label>
                                        <input type="password" name="password" class="form-control" placeholder="Password" minlength="6" required="">
                                        <?php if($errors->has('password')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group <?php echo e($errors->has('password-confirm') ? 'has-error' : ''); ?>">
                                        <label for="nome">Confirmar contraseña</label>
                                        <input type="password" name="password_confirmation" class="form-control" placeholder="Confirm Password" minlength="6" required="">
                                        <?php if($errors->has('password-confirm')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('password-confirm')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-lg-12"></div>
                                <div class="col-lg-6">
                                    <p class="text-muted"><b><i class="fa fa-warning"></i></b> Editando contraseña <b><?php echo e($user->name); ?></b>.</p>
                                </div> 
                                <div class="col-lg-6">
                                   <button type="submit" class="btn btn-primary pull-right"><i class="fa fa-fw fa-save"></i> Guardar</button>
                                </div>
                            </div>
                        </form>
    				</div>
    			</div>
    		</div>
    	</div>    
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLTE.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yael/Documents/Proyectos/Sistema de internalización/Laravel-AdminLTE/resources/views/users/edit_password.blade.php ENDPATH**/ ?>