<?php $__env->startSection('icon_page', 'unlock-alt'); ?>

<?php $__env->startSection('title', 'Cursos contratados'); ?>

<?php $__env->startSection('menu_pagina'); ?>	
		
	<li role="presentation">
		<a href="<?php echo e(route('course')); ?>" class="link_menu_page">
			<i class="fa fa-user"></i> Cursos
		</a>								
	</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
    <div class="box box-primary">
		<div class="box-body">
			<div class="row" style="height: calc(100vh - 220px) !important;">
                <div class="col-md-7">
                    <div class="row">
                        <div class="col-md-12">
                            <img src="/img/logo_int.png" style="width: 25%; padding:5px;" alt="">
                        </div>
                    </div>
                
                    <div class="col-md-12" style="margin: auto; padding-top: 2%; padding-bottom: 2%;">
                        
                        <img src="/img/teaser.png" style="width: 100%; padding:5px;" alt="">
                    </div>

                    <div class="col-md-12">
                        <div class="col-md-6 col-md-offset-3">
                                <a href="/course/view-into-course/<?php echo e($courses->id); ?>?estancia=1" class="btn btn-danger" style="color:white; width:100%; border-radius: 10px; margin-top: 10px;">OPCIONES DE MOVILIDAD</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-5">
                    <div class="col-md-12">
                        <img src="/img/img_1.png" style="width: 100%; padding:5px;" alt="">
                    </div>
                </div>
			</div>
		</div>
	</div>    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.AdminLTE._includes._data_tables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.AdminLTE.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yael/Documents/Proyectos/Sistema de internalización/Laravel-AdminLTE/resources/views/courses/view_course_into_internalizacion_prev.blade.php ENDPATH**/ ?>