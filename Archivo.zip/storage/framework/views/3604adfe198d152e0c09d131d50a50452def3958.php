<?php $__env->startSection('icon_page', 'unlock-alt'); ?>

<?php $__env->startSection('title', 'Cursos contratados'); ?>

<?php $__env->startSection('menu_pagina'); ?>	
		
	<li role="presentation">
		<a href="<?php echo e(route('course')); ?>" class="link_menu_page">
			<i class="fa fa-user"></i> Cursos
		</a>								
	</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
    <div class="box box-primary">
		<div class="box-body">
			<div class="row">
			
            <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            
            <div class="col-sm-6 col-md-3 col-12">
                <div class="thumbnail">
                    <img src="https://empleabilidad.redmundua.com/theme/moove/pix/3.jpg" alt="...">
                    <div class="caption">
                        <h5><?php echo e($course->nombre); ?> (<?php echo e($course->codigo); ?>)</h5>
                        
                            <?php if($course->empresa_id == $empresa_id and $course->universidad_id == $course->id): ?>
                                
                                
                                <p class="text-center" style="margin-top: 15px;" data-toggle="modal" data-target="#modal-delete-<?php echo e($course->id_view); ?>"><a href="/course/view-into-course/<?php echo e($course->id); ?>" class="btn btn-success" title="Ingresar al curso (<?php echo e($course->nombre); ?>)" type="submit" text="Entrar" value="Entrar" id="btn-entrar">Entrar</a></p>
                            <?php else: ?>
                               
                            
                            <?php endif; ?>
                    </div>
                </div>
            </div>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No hay cursos registrados</p>
            <?php endif; ?>


                						
			</div>
		</div>
	</div>    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.AdminLTE._includes._data_tables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.AdminLTE.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yael/Documents/Proyectos/Sistema de internalización/Laravel-AdminLTE/resources/views/courses/view_course_into.blade.php ENDPATH**/ ?>