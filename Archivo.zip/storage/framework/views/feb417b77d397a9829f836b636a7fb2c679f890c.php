<?php $__env->startSection('icon_page', 'plus'); ?>

<?php $__env->startSection('title', 'Add Permission'); ?>

<?php $__env->startSection('menu_pagina'); ?>	
		
	<li role="presentation">
		<a href="<?php echo e(route('role')); ?>" class="link_menu_page">
			<i class="fa fa-unlock-alt"></i> Permissions
		</a>								
	</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
        
    <div class="box box-primary">
		<div class="box-body">
			<div class="row">
				<div class="col-md-12">	
					 <form action="<?php echo e(route('role.store')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="active" value="1">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                    <label for="nome">Name</label>
                                    <input type="text" name="name" class="form-control" maxlength="30" minlength="4" placeholder="Name" required="" value="<?php echo e(old('name')); ?>" autofocus>
                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group <?php echo e($errors->has('label') ? 'has-error' : ''); ?>">
                                    <label for="nome">Description</label>
                                    <input type="text" name="label" class="form-control" placeholder="Description" required="" value="<?php echo e(old('label')); ?>">
                                    <?php if($errors->has('label')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('label')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>                            
                            <div class="col-lg-12">
                                <label for="nome">Permissions</label>
                                <?php $__currentLoopData = $permission_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($permission_group->id > 1): ?>               
                                        <div class="panel box box-default">
                                            <div class="box-header with-border">
                                                <h4 class="box-title">
                                                <a data-toggle="collapse" data-parent="#accordion" href="#<?php echo e($permission_group->id); ?>" aria-expanded="false" class="collapsed">
                                                    <?php echo e($permission_group->name); ?>

                                                </a>
                                                </h4>
                                            </div>
                                            <div id="<?php echo e($permission_group->id); ?>" class="panel-collapse collapse">
                                                <div class="box-body">                               
                                                    <?php $__currentLoopData = $permission_group->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-lg-3">
                                                            <label><input type="checkbox" name="permissions[]" value="<?php echo e($permission->id); ?>" class="icheck minimal"> <?php echo e($permission->label); ?></label>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                     
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
                            </div>
                            <div class="col-lg-6"></div> 
                            <div class="col-lg-6">
                               <button type="submit" class="btn btn-primary pull-right"><i class="fa fa-fw fa-plus"></i> Add</button>
                            </div>
                        </div>
                    </form>
				</div>
			</div>
		</div>
	</div>    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('layout_js'); ?>    

    <script> 
        $(function(){            
            $('.icheck').iCheck({
              checkboxClass: 'icheckbox_square-blue',
              radioClass: 'iradio_square-blue'
            });
        }); 

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLTE.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yael/Documents/Proyectos/Sistema de internalización/Laravel-AdminLTE/resources/views/users/roles/create.blade.php ENDPATH**/ ?>