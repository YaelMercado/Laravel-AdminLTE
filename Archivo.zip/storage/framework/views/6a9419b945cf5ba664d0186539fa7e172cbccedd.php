<?php $__env->startSection('icon_page', 'unlock-alt'); ?>

<?php $__env->startSection('title', 'Cursos'); ?>

<?php $__env->startSection('menu_pagina'); ?>	

	<?php if(Auth::user()->can('create-course', '')): ?>	
	<li role="presentation">
		<a href="<?php echo e(route('course.create')); ?>" class="link_menu_page">
			<i class="fa fa-plus"></i> Añadir 
		</a>								
	</li>
	<?php endif; ?>
	<?php if(Auth::user()->can('show-course', '')): ?>
	<li role="presentation">
		<a href="<?php echo e(route('user')); ?>" class="link_menu_page">
			<i class="fa fa-user"></i> Usuarios
		</a>								
	</li>
	<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
        
    <div class="box box-primary">
		<div class="box-body">
			<div class="row">
				<div class="col-md-12">	
					<div class="table-responsive">
						<table id="tabelapadrao" class="table table-condensed table-bordered table-hover">
							<thead>
								<tr>			 
									<th>Nombre</th>			 
									<th>Descripción</th>
									<th>Fecha de creación</th>			 
									<th class="text-center">Acciones</th>			 
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									
										<tr>
											<td><?php echo e($course->nombre); ?></td>             
											<td><?php echo e($course->codigo); ?></td>               
											<td><?php echo e($course->created_at->format('d/m/Y H:i')); ?></td>             
											<td class="text-center"> 
											<?php if(Auth::user()->can('show-course', '')): ?>
												 <a class="btn btn-default  btn-xs" href="<?php echo e(route('course.show', $course->id)); ?>" title=See <?php echo e($course->nombre); ?>"><i class="fa fa-eye">   </i></a>						 
											<?php endif; ?>
											<?php if(Auth::user()->can('edit-course', '')): ?>
												 <a class="btn btn-warning  btn-xs" href="<?php echo e(route('course.edit', $course->id)); ?>" title="Edit <?php echo e($course->nombre); ?>"><i class="fa fa-pencil"></i></a>
											<?php endif; ?>
											<?php if(Auth::user()->can('destroy-course', '')): ?>	 
												 <a class="btn btn-danger  btn-xs" href="#" title="Eliminar <?php echo e($course->name); ?>" data-toggle="modal" data-target="#modal-delete-<?php echo e($course->id); ?>"><i class="fa fa-trash"></i></a>
											<?php endif; ?>
											</td> 
										</tr>
										<div class="modal fade" id="modal-delete-<?php echo e($course->id); ?>">
											<div class="modal-dialog">
												<div class="modal-content">
													<div class="modal-header">
														<button type="button" class="close" data-dismiss="modal" aria-label="Close">
															<span aria-hidden="true">×</span>
														</button>
														<h4 class="modal-title"><i class="fa fa-warning"></i> Caution!!</h4>
													</div>
													<div class="modal-body">
														<p>¿Desea eliminar el curso (<?php echo e($course->nombre); ?>) ?</p>
													</div>
													<div class="modal-footer">
														<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancelar</button>
														<a href="<?php echo e(route('course.destroy', $course->id)); ?>" ><button type="button" class="btn btn-danger"><i class="fa fa-trash"></i> Eliminar</button></a>
													</div>
												</div>
											</div>
										</div>
									
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
							<tfoot>
								<tr>		 
									<th>Nombre</th>			 
									<th>Descripción</th>
									<th>Fecha de creación</th>			 
									<th class="text-center">Acciones</th>			 
								</tr>
							</tfoot>
						</table>
					</div>
				</div>								
				<div class="col-md-12 text-center">
					<?php echo e($courses->links()); ?>

				</div>
			</div>
		</div>
	</div>    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.AdminLTE._includes._data_tables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.AdminLTE.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yael/Documents/Proyectos/Sistema de internalización/Laravel-AdminLTE/resources/views/courses/index.blade.php ENDPATH**/ ?>