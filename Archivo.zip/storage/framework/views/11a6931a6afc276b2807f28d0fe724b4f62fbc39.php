<?php $__env->startSection('icon_page', 'plus'); ?>

<?php $__env->startSection('title', 'Agregar Estancias'); ?>

<?php $__env->startSection('menu_pagina'); ?>	
		
	<li role="presentation">
		<a href="<?php echo e(route('course')); ?>" class="link_menu_page">
			<i class="fa fa-user"></i> Estancias
		</a>								
	</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
        
    <div class="box box-primary">
		<div class="box-body">
			<div class="row">
				<div class="col-md-12">	
					 <form action="<?php echo e(route('estancias.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="active" value="1">
                        <div class="row">
                            <div class="col-md-6 col-lg-6 col-6">
                                <label for="universidad">Tipo de Estancia</label>
                                <select class="form-control select2" name="type_estancia" id="type_estancia" required="required">
                                   <option value="1">Estancia Corta</option>
                                   <option value="2">Estancia de Verano</option>
                                   <option value="3">Estancia Semestrak</option>
                                </select>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                    <label for="nome">Nombre</label>
                                    <input type="text" name="name" class="form-control" maxlength="30" minlength="4" placeholder="Nombre" required="" value="<?php echo e(old('name')); ?>" autofocus>
                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-12 col-lg-12 col-12">
                                <div class="form-group ">
                                    <label for="universidad">Descripción</label>
                                    <textarea class="form-control" id="summary_ckeditor" name="summary_ckeditor"></textarea>
                                    <?php if($errors->has('summary_ckeditor')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('summary_ckeditor')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-6 col-6">
                                <div class="form-group ">
                                    <label for="universidad">Fecha Inicio</label>
                                    <input type="date" class="form-control" required="required" id="inicio" name="inicio">
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-6 col-6">
                                <div class="form-group ">
                                    <label for="universidad">Fecha Fin</label>
                                    <input type="date" class="form-control" required="required" id="fin" name="fin">
                            
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                                    <label for="nome">País Destino</label>
                                    <input type="text" name="pais" class="form-control" placeholder="País" value="<?php echo e(old('pais')); ?>">
                                    <?php if($errors->has('pais')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('pais')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-6 col-6">
                                <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                                    <label for="nome">Universidad Destino</label>
                                    <input type="text" name="universidad" class="form-control" placeholder="Universidad" value="<?php echo e(old('universidad')); ?>">
                                    <?php if($errors->has('universidad')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('universidad')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-6 col-6">
                                <div class="form-group ">
                                    <label for="universidad">Imagen País Destino</label>
                                    <input type="file" class="form-control-file" name="destino">
                                    <?php if($errors->has('destino')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('destino')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            
                            <div class="col-md-6 col-lg-6 col-6">
                                <div class="form-group ">
                                    <label for="universidad">Imagen Universidad Destino</label>
                                    <input type="file" class="form-control-file" name="unidestino">
                                    <?php if($errors->has('unidestino')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('unidestino')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-6 col-6">
                                <div class="form-group ">
                                    <label for="universidad">Archivo de reglamento y politicas</label>
                                    <input type="file" class="form-control-file" name="file-politicas-reglamento">
                                    <?php if($errors->has('file-politicas-reglamento')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('politicas')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-6 col-6">
                                <div class="form-group ">
                                    <label for="universidad">Archivo de Agenda</label>
                                    <input type="file" class="form-control-file" name="file-agenda">
                                    <?php if($errors->has('file-agenda')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('agenda')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-md-12 col-lg-12 col-12">
                                <div class="form-group ">
                                    <label for="universidad">Imagen de fondo</label>
                                    <input type="file" class="form-control-file" name="fondo">
                                    <?php if($errors->has('fondo-img')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('fondo')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="col-lg-6"></div> 
                            <div class="col-lg-6">
                               <button type="submit" class="btn btn-primary pull-right"><i class="fa fa-fw fa-plus"></i> Añadir</button>
                            </div>
                        </div>
                    </form>
				</div>
			</div>
		</div>
	</div>    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('layout_js'); ?>
    
    <script> 
        $(function(){             
            $('.select2').select2({
                "language": {
                    "noResults": function(){
                        return "Nenhum registro encontrado.";
                    }
                }
            }); 

            $('.n_alumnos').change(function (){
               var alumnos = $(this).val();

               if (alumnos > 0){
                var profesores = parseInt(alumnos) / 10;
                profesores = Math.floor(profesores)

                $('.n_profesores').val(profesores);
               }
            });
        }); 

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLTE.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yael/Documents/Proyectos/Sistema de internalización/Laravel-AdminLTE/resources/views/estancias/create.blade.php ENDPATH**/ ?>