<?php $__env->startSection('icon_page', 'eye'); ?>

<?php $__env->startSection('title', 'View Permission'); ?>

<?php $__env->startSection('menu_pagina'); ?>	
		
	<li role="presentation">
		<a href="<?php echo e(route('role')); ?>" class="link_menu_page">
			<i class="fa fa-unlock-alt"></i> Permissions
		</a>								
	</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
    <?php if($role->id != 1): ?>    
        <div class="box box-primary">
    		<div class="box-body">
    			<div class="row">
    				<div class="col-md-12">	
                        <h4><b>Name:</b> <?php echo e($role->name); ?></h4>
    					<h4><b>Description:</b> <?php echo e($role->label); ?></h4>
                        <h4><b>Permissions:</b></h4>
                        <?php $__currentLoopData = $permission_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>               
                            <div class="panel box box-default">
                                <div class="box-header with-border">
                                    <h4 class="box-title">
                                    <a data-toggle="collapse" data-parent="#accordion" href="#<?php echo e($permission_group->id); ?>" aria-expanded="false" class="collapsed">
                                        <?php echo e($permission_group->name); ?>

                                    </a>
                                    </h4>
                                </div>
                                <div id="<?php echo e($permission_group->id); ?>" class="panel-collapse collapse">
                                    <div class="box-body">                              
                                        <?php $__currentLoopData = $permission_group->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-lg-3">
                                                <label><input type="checkbox" name="permissions[]" value="<?php echo e($permission->id); ?>" class="icheck minimal"
                                                    <?php if(in_array($permission->id, $permissions_ids)): ?>
                                                        checked
                                                    <?php endif; ?>
                                                    disabled> <?php echo e($permission->label); ?></label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                     
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <p class="help-block"><i class="fa fa-clock-o"></i> Created on: <?php echo e($role->created_at->format('d/m/Y H:i')); ?></p>
                        <p class="help-block"><i class="fa fa-refresh"></i> Last update: <?php echo e($role->updated_at->format('d/m/Y H:i')); ?></p>
                        <div class="pull-right">               
                            <a href="<?php echo e(route('role.edit', $role->id)); ?>" title="Editar <?php echo e($role->name); ?>"><button type="button" class="btn btn-warning btn-sm btn-flat"><i class="fa fa-pencil"></i> Edit</button></a>
                        </div>
    				</div>
    			</div>
    		</div>
    	</div>
    <?php endif; ?>    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('layout_js'); ?>    

    <script> 
        $(function(){            
            $('.icheck').iCheck({
              checkboxClass: 'icheckbox_square-blue',
              radioClass: 'iradio_square-blue'
            });
        }); 

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLTE.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yael/Documents/Proyectos/Sistema de internalización/Laravel-AdminLTE/resources/views/users/roles/show.blade.php ENDPATH**/ ?>