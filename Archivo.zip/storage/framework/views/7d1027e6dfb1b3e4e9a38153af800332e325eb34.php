<header class="main-header">
  <a href="<?php echo e(route('home')); ?>" class="logo">
    <span class="logo-mini"><?php echo \App\Models\Config::find(1)->app_name_abv; ?></span>
    <span class="logo-lg"><?php echo \App\Models\Config::find(1)->app_name; ?></span>
  </a>
  <nav class="navbar navbar-static-top">
    <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
      <span class="sr-only">Toggle navigation</span>
    </a>
    <div class="navbar-custom-menu">
      <ul class="nav navbar-nav">          
        <li class="dropdown user user-menu">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <?php if(file_exists(Auth::user()->avatar)): ?>
              <img src="<?php echo e(asset(Auth::user()->avatar)); ?>" class="user-image">
            <?php else: ?>
              <img src="<?php echo e(asset('public/img/config/nopic.png')); ?>" class="user-image">
            <?php endif; ?>            
            <span class="hidden-xs">
            <?php if(Auth::user('name')): ?>
              <?php echo e(Auth::user()->name); ?>

            <?php endif; ?>
            </span>
          </a>
          <ul class="dropdown-menu">
            <li class="user-header">
              <?php if(file_exists(Auth::user()->avatar)): ?>
                <img src="<?php echo e(asset(Auth::user()->avatar)); ?>" class="img-circle">
              <?php else: ?>
                <img src="<?php echo e(asset('public/img/config/nopic.png')); ?>" class="img-circle">
              <?php endif; ?>
              <p>
                <?php if(Auth::user('name')): ?>
                  <?php echo e(Auth::user()->name); ?>

                <?php endif; ?>
                <small>Member Since <?php echo e(Auth::user()->created_at->format('M Y')); ?></small>
              </p>
            </li>
            <li class="user-footer">
              <div class="pull-left">
                <a href="<?php echo e(route('profile')); ?>" class="btn btn-default btn-flat">Profile</a>
              </div>
              <div class="pull-right">
                <a href="<?php echo e(route('logout')); ?>" class="btn btn-default btn-flat" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Logout</a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                </form>
              </div>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  </nav>
</header><?php /**PATH /Users/yael/Documents/Proyectos/Sistema de internalización/Laravel-AdminLTE/resources/views/layouts/AdminLTE/_includes/_menu_superior.blade.php ENDPATH**/ ?>