<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('layout_css'); ?>
    <style>
        #box-login-personalize{
            width: 360px;
            margin: 3% auto;
        }
        .login-page{
            background-size: cover;
            background-image: url(https://empleabilidad.redmundua.com/theme/moove/pix/1.jpg);
        }
        .login-logo a, .register-logo a {
            color: white !important;
        }
        .btn-primary {
            background-color: #259a8e;
            border-color: #1a8773;
        }

        .login-box-body, .register-box-body {
            background: #ffffffe8;
            padding: 20px;
            border-top: 0;
            color: #666;
            border-radius: 5px;
        }
    </style>
<?php $__env->stopSection(); ?>

<!DOCTYPE html>
<html lang="en">
    <head>

        <?php echo $__env->make('layouts.AdminLTE._includes._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </head>
    <body class="hold-transition login-page">
        <div id="box-login-personalize">
            <div class="login-logo">
                
                <?php if(\App\Models\Config::find(1)->img_login == 'T'): ?>
                    <img src="<?php echo e(asset(\App\Models\Config::find(1)->caminho_img_login)); ?>" width="<?php echo e(\App\Models\Config::find(1)->tamanho_img_login); ?>%"/>
                    <br/>
                <?php endif; ?>
               
               <?php echo \App\Models\Config::find(1)->titulo_login; ?>

            </div>
            <div class="login-box-body">
                <p class="login-box-msg"><strong>Inicio de sesión</strong></p>
                <form  method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group has-feedback">
                        <input id="email" type="text" class="form-control" placeholder="Usuario" name="email" value="<?php echo e(old('email')); ?>" autofocus required="" AUTOCOMPLETE='off'>
                        <span class="glyphicon glyphicon-user form-control-feedback"></span>
                    </div>
                    <div class="form-group has-feedback">
                        <input id="password" type="password" class="form-control" placeholder="Contraseña" name="password" required="" AUTOCOMPLETE='off'>
                        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                        <?php if($errors->has('email')): ?>
                            <br/>
                            <span class="help-block">
                                <strong><p class="text-red"><?php echo e($errors->first('email')); ?></p></strong>
                            </span>
                        <?php endif; ?>
                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="row">  
                        <!--<div class="col-xs-8">
                          <div class="checkbox icheck">
                            <label>
                              <input name="remember" type="checkbox" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember me
                            </label>
                          </div>
                        </div>-->
                        <div class="col-xs-12">
                          <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
                        </div>  
                        <br/><br/><br/>
                        <!--<div class="col-xs-12">
                            <center>
                                <a href="<?php echo e(route('password.request')); ?>">Forgot password?</a>
                                <br/>
                                <a href="<?php echo e(route('register')); ?>">Sign up</a>
                            </center> -->                     
                        </div>
                    </div>                  
                </form> 
            </div>
        </div>

        <?php echo $__env->make('layouts.AdminLTE._includes._script_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script>
          $(function () {
            $('input').iCheck({
              checkboxClass: 'icheckbox_square-blue',
              radioClass: 'iradio_square-blue',
              increaseArea: '20%'
            });
          });
        </script>
    </body>
</html><?php /**PATH /Users/yael/Documents/Proyectos/Sistema de internalización/Laravel-AdminLTE/resources/views/auth/login.blade.php ENDPATH**/ ?>