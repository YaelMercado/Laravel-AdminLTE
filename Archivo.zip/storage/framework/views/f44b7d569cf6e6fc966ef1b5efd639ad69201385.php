 

<?php $__env->startSection('icon_page', 'user'); ?> 

<?php $__env->startSection('title', 'Perfil de usuario'); ?> 

<?php $__env->startSection('content'); ?> 

<div class="row">
	<div class="col-md-3">
		<div class="box box-primary">
			<div class="box-body box-profile">
				<?php if(file_exists(Auth::user()->avatar)): ?>
	              <img src="<?php echo e(asset(Auth::user()->avatar)); ?>" class="profile-user-img img-responsive img-circle">
	            <?php else: ?>
	              <img src="<?php echo e(asset('img/config/nopic.png')); ?>" class="profile-user-img img-responsive img-circle">
	            <?php endif; ?>							
				<h3 class="profile-username text-center">
					<?php if(Auth::user('name')): ?>
		              <?php echo e(Auth::user()->name); ?>

		            <?php endif; ?>
				</h3>	
				<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(in_array($role->id, $roles_ids)): ?>
                        <div class="text-center"><span class="label label-primary"><?php echo e($role->name); ?></span></div> 
                    <?php endif; ?>                                             
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
			</div>
		</div>		
	</div>
	<div class="col-md-9">
		<div class="nav-tabs-custom">
			<ul class="nav nav-tabs">
				<li class="active"><a href="#profile" data-toggle="tab"><i class="fa fa-fw fa-user"></i> Perfil</a></li>
				<li><a href="#settings" data-toggle="tab"><i class="fa fa-fw fa-key"></i> Contraseña</a></li>
				<li><a href="#avatar" data-toggle="tab"><i class="fa fa-fw fa-file-photo-o"></i> Avatar</a></li>
			</ul>
			<div class="tab-content">
				<div class="active tab-pane" id="profile">
					<form action="<?php echo e(route('profile.update.profile',$user->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="put">
						<div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                            <label for="nome">Nombre</label>
                            <input type="text" name="name" class="form-control" maxlength="30" minlength="4" placeholder="Name" required="" value="<?php echo e($user->name); ?>">
                            <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
						<div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                            <label for="nome">Correo</label>
                            <input type="email" name="email" class="form-control" placeholder="E-mail" required="" value="<?php echo e($user->email); ?>">
                            <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>	
                        <div class="form-group text-right">
                           <button type="submit" class="btn btn-primary"><i class="fa fa-fw fa-save"></i> Guardar Perfil</button>
                        </div>
					</form>						
				</div>
				<div class="tab-pane" id="settings">
					<form action="<?php echo e(route('profile.update.password',$user->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="put">
						<div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                            <label for="nome">Password</label>
                            <input type="password" name="password" class="form-control" placeholder="Password" minlength="6" required="">
                            <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
						<div class="form-group <?php echo e($errors->has('password-confirm') ? 'has-error' : ''); ?>">
                            <label for="nome">Confirmar Contraseña</label>
                            <input type="password" name="password_confirmation" class="form-control" placeholder="Confirm Password" minlength="6" required="">
                            <?php if($errors->has('password-confirm')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('password-confirm')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>	
                        <div class="form-group text-right">
                           <button type="submit" class="btn btn-primary"><i class="fa fa-fw fa-save"></i> Gardar Contraseña</button>
                        </div>
					</form>						
				</div>
				<div class="tab-pane" id="avatar">
					<form action="<?php echo e(route('profile.update.avatar',$user->id)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="put">
                        <div class="form-group <?php echo e($errors->has('avatar') ? 'has-error' : ''); ?>">
							<label>Avatar</label>
                        	<input type="file"  class="form-control-file" name="avatar">
                        	<?php if($errors->has('avatar')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('avatar')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>	
                        <div class="form-group text-right">
                           <button type="submit" class="btn btn-primary"><i class="fa fa-fw fa-save"></i> Guardar Avatar</button>
                        </div>
                    </form>
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLTE.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yael/Documents/Proyectos/Sistema de internalización/Laravel-AdminLTE/resources/views/profile/index.blade.php ENDPATH**/ ?>