<?php $__env->startSection('icon_page', 'plus'); ?>

<?php $__env->startSection('title', 'Agregar Curso'); ?>

<?php $__env->startSection('menu_pagina'); ?>	
		
	<li role="presentation">
		<a href="<?php echo e(route('course')); ?>" class="link_menu_page">
			<i class="fa fa-user"></i> Cursos
		</a>								
	</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
        
    <div class="box box-primary">
		<div class="box-body">
			<div class="row">
				<div class="col-md-12">	
					 <form action="<?php echo e(route('course.store')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="active" value="1">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                    <label for="nome">Nombre</label>
                                    <input type="text" name="name" class="form-control" maxlength="30" minlength="4" placeholder="Name" required="" value="<?php echo e(old('name')); ?>" autofocus>
                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                                    <label for="nome">Descripción</label>
                                    <input type="text" name="desc" class="form-control" placeholder="Descripción" required="" value="<?php echo e(old('desc')); ?>">
                                    <?php if($errors->has('desc')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('desc')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="col-lg-6"></div> 
                            <div class="col-lg-6">
                               <button type="submit" class="btn btn-primary pull-right"><i class="fa fa-fw fa-plus"></i> Añadir</button>
                            </div>
                        </div>
                    </form>
				</div>
			</div>
		</div>
	</div>    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('layout_js'); ?>
    
    <script> 
        $(function(){             
            $('.select2').select2({
                "language": {
                    "noResults": function(){
                        return "Nenhum registro encontrado.";
                    }
                }
            }); 
        }); 

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLTE.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yael/Documents/Proyectos/Sistema de internalización/Laravel-AdminLTE/resources/views/courses/create.blade.php ENDPATH**/ ?>